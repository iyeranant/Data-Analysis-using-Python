# Group 2 
## Data Filtering and Smoothing


| Name | Matriculation No. | Contribution |
| ------ | ------ | ------ |
| Abdulkader Tarakji | 11146935 | Smoothing with simple, cumulative, and exponential moving average (smoothen.py)  |
| Anantharaman Iyer | 11147113 | Cleaning data techniques (other_functions.py) |
| Andrey Domnyshev | 11146992 | Fill in missing values using linear interpolation only (interpolation_linear.py) |
| Fernando Tovar | 11145554 | Outlier replacement with 1D interpolation and missing values replacement with 1D interpolation (interpolation1d.py) |
| Forough Rafiee| 11147115 | Outlier replacement with 1D interpolation and missing values replacement with 1D interpolation (interpolation1d.py ) |
| Kumudaya Nayanajith | 11150249 | Outlier removal with IQR method (remove_outlier.py) |
| Larissa Melo | 11145746 | Outlier removal with Z-Score method (remove_outlier.py) |
