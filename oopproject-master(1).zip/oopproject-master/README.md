# The following libraries were used and are necessary to run the code:
-	Pandas
-	Numpy
-	PIL/Pillow
-	Matplotlib
-	Sklearn
-	Keras
-	Pydot
-	Seaborn
-	Scipy
-	Openpyxl
-	Tensorflow

# Final Group Division:

## Group 1 - GUI
- Christian Ndukwe - 11139460
#### Task: 
-   Application design,
-   Source code development (except the codes in the folders mention by other groups)
-   General Code organization/refractoring and 
-   Code integration and testing.

## Group 2 - Data Filtering and Smoothing
### Source Code Directory: analysis/data_preparation/
- Abdulkader Tarakji - 11146935
- Anantharaman Iyer - 11147113
- Andrey Domnyshev - 11146992
- Fernando Tovar - 11145554
- Forough Rafiee - 11147115
- Kumudaya Nayanajith - 11150249
- Larissa Melo - 11145746

## Group 3 – AI based models for Regression and Classification
### Source Code Directory: analysis/ai/
- Ashika Dev Teres - 11146490
- Celena Betancourt - 11148260
- Mirco Fredrichs - 11094675
- Peter Haupts - 11146179
- Quentin Lyons - 11146991
- Ibrahim Mammadli - 11146028

## Group 4 – Regression and Classification
### Source Code Directory: analysis/classical/
- Aashika Srinivas - 11148272
- Shail Patel	- 11148263
- Amir Shrestha -	11148269
- Faaiz Ahmed	- 11148258
- Aisha Nasir	- 11148832
- Ravi Sankar	- 11146933




