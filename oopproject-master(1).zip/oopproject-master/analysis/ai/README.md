## AI based Classification and Regression Models - Group 3


### Ashika Dev Teres ​ 11146490 ​

### Celena Betancourt ​11148260 ​

### Mirco Fredrichs ​  11094675 ​

### Peter Haupts ​     11146179 ​

### Quentin Lyons ​    11146991 ​

### Ibrahim Mammadli ​ 11146028 ​

