## Classification and Regression Algorithms (Classical) - Group 4

### Aashika Srinivas ​ 11148272 ​

### Shail Patel ​      11148263 ​

### Amir Shrestha ​    11148269 ​

### Faaiz Ahmed ​      11148258 ​

### Aisha Nasir ​      11148832 ​

### Ravi Sankar ​      11146933 ​
